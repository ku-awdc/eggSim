## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library("eggSim")
library("tidyverse")

## -----------------------------------------------------------------------------
community_mean <- 3.16

## -----------------------------------------------------------------------------
reduction <- 1 - 0.8

## -----------------------------------------------------------------------------
# Between individuals:
cv_between <- 1.5
# Within an individual over different days:
cv_within <- 0.75
# Within the same individual and the same day:
cv_slide <- 0.25
# Variation in efficacy between individuals:
cv_reduction <- 0

## -----------------------------------------------------------------------------
combined_k(cv_between, cv_within, cv_slide, cv_reduction)

## -----------------------------------------------------------------------------
budget <- 1200
second_slide_cost <- 0.621

## -----------------------------------------------------------------------------
efficacies <- eggSim(R=1e3, summarise=FALSE, reduction=reduction, budget=budget, second_slide_cost=second_slide_cost, community_mean=community_mean, cv_between=cv_between, cv_within=cv_within, cv_slide=cv_slide, cv_reduction=cv_reduction)

## -----------------------------------------------------------------------------
str(efficacies)

## -----------------------------------------------------------------------------
ggplot(efficacies, aes(x=Design, y=ArithmeticEfficacy)) +
  geom_boxplot()

## -----------------------------------------------------------------------------
community_mean <- c(3.16, 23.5)
reduction <- 1 - c(0.95, 0.8)

## -----------------------------------------------------------------------------
biases <- eggSim(R=1e3, summarise=TRUE, parallelise=2, reduction=reduction, budget=budget, second_slide_cost=second_slide_cost, community_mean=community_mean, cv_between=cv_between, cv_within=cv_within, cv_slide=cv_slide, cv_reduction=cv_reduction)

## -----------------------------------------------------------------------------
biases %>%
  select(OverallMean, ObsPrev, Target, Design, MeanN, Bias, MedianBias, Variance) %>%
  arrange(OverallMean, Target, Design) %>%
  print(n=Inf)

## ----eval=FALSE---------------------------------------------------------------
#  ?`eggSim-package`

## -----------------------------------------------------------------------------
sessionInfo()

