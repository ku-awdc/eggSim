library(testthat)
library(eggSim)

test_check("eggSim")
