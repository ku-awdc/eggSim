# eggSim
An R package to simulate datasets representing egg reduction rate data


## TODO

Add a function to give approximate overall k based on cv partitions
