#ifndef ENUMS_H
#define ENUMS_H

enum class designs { NS, SS, SSR };
enum class methods { custom };
enum class dists { rgamma, rbeta, rnbinom, rpois, identity, rlnorm };

#endif // ENUMS_H
